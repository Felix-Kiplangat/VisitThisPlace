# tourism
This is a website that helps tourists and other people intrested in Rwanda.
It is a guide to all tourist centers that are availble in Rwanda 
it also points to the major ones
